import Layout from "../components/MyLayout"

const content = (<p>This is the about page</p>)

export default () => (<Layout content={content}/>)